--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY app_private.user_account DROP CONSTRAINT user_account_user_id_fkey;
ALTER TABLE ONLY app_private.user_3p_auth DROP CONSTRAINT user_3p_auth_user_id_fkey;
DROP TRIGGER user_updated_on ON app_public."user";
DROP TRIGGER user_account_updated_on ON app_private.user_account;
DROP TRIGGER user_3p_auth_updated_on ON app_private.user_3p_auth;
ALTER TABLE ONLY app_public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY app_public.demo_form_public DROP CONSTRAINT demo_form_public_pkey;
ALTER TABLE ONLY app_public.demo_form_public DROP CONSTRAINT demo_form_public_email_key;
ALTER TABLE ONLY app_private.user_account DROP CONSTRAINT user_account_primary_email_key;
ALTER TABLE ONLY app_private.user_account DROP CONSTRAINT user_account_pkey;
ALTER TABLE ONLY app_private.user_3p_auth DROP CONSTRAINT user_3p_auth_pkey;
ALTER TABLE ONLY app_private.user_3p_auth DROP CONSTRAINT user_3p_auth_email_key;
ALTER TABLE app_public."user" ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE app_public.demo_form_public ALTER COLUMN demo_id DROP DEFAULT;
DROP SEQUENCE app_public.user_user_id_seq;
DROP SEQUENCE app_public.demo_form_public_demo_id_seq;
DROP TABLE app_public.demo_form_public;
DROP TABLE app_private.user_account;
DROP TABLE app_private.user_3p_auth;
DROP FUNCTION app_public.register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner);
DROP FUNCTION app_public."current_user"();
DROP TABLE app_public."user";
DROP FUNCTION app_public.authenticate(username text, password text);
DROP FUNCTION app_private.set_modified_on();
DROP TYPE app_public.jwt_token;
DROP TYPE app_private.auth_partner;
DROP TYPE app_private.account_status;
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA app_public;
DROP SCHEMA app_private;
--
-- Name: app_private; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA app_private;


ALTER SCHEMA app_private OWNER TO postgres;

--
-- Name: app_public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA app_public;


ALTER SCHEMA app_public OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: account_status; Type: TYPE; Schema: app_private; Owner: postgres
--

CREATE TYPE app_private.account_status AS ENUM (
    'active',
    'disabled',
    'deleted'
);


ALTER TYPE app_private.account_status OWNER TO postgres;

--
-- Name: auth_partner; Type: TYPE; Schema: app_private; Owner: postgres
--

CREATE TYPE app_private.auth_partner AS ENUM (
    'Facebook',
    'Twitter',
    'Instagram'
);


ALTER TYPE app_private.auth_partner OWNER TO postgres;

--
-- Name: jwt_token; Type: TYPE; Schema: app_public; Owner: postgres
--

CREATE TYPE app_public.jwt_token AS (
	role text,
	user_id integer
);


ALTER TYPE app_public.jwt_token OWNER TO postgres;

--
-- Name: set_modified_on(); Type: FUNCTION; Schema: app_private; Owner: postgres
--

CREATE FUNCTION app_private.set_modified_on() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  new.modified_on := current_timestamp;
  return new;
END;
$$;


ALTER FUNCTION app_private.set_modified_on() OWNER TO postgres;

--
-- Name: authenticate(text, text); Type: FUNCTION; Schema: app_public; Owner: postgres
--

CREATE FUNCTION app_public.authenticate(username text, password text) RETURNS app_public.jwt_token
    LANGUAGE plpgsql STRICT SECURITY DEFINER
    AS $_$
DECLARE
  account app_private.user_account;
BEGIN
  Select a.* Into account
  From app_private.user_account as a
  Where a.username = $1;

  if account.password_hash = crypt(password, account.password_hash) then
    return ('app_authorized', account.user_id)::app_public.jwt_token;
  else
    return null;
  end if;
END;
$_$;


ALTER FUNCTION app_public.authenticate(username text, password text) OWNER TO postgres;

--
-- Name: FUNCTION authenticate(username text, password text); Type: COMMENT; Schema: app_public; Owner: postgres
--

COMMENT ON FUNCTION app_public.authenticate(username text, password text) IS 'Creates a JWT token that will securely identify a user and give them certain permissions.';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: user; Type: TABLE; Schema: app_public; Owner: postgres
--

CREATE TABLE app_public."user" (
    user_id integer NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    created_on timestamp with time zone DEFAULT now(),
    modified_on timestamp with time zone DEFAULT now()
);


ALTER TABLE app_public."user" OWNER TO postgres;

--
-- Name: current_user(); Type: FUNCTION; Schema: app_public; Owner: postgres
--

CREATE FUNCTION app_public."current_user"() RETURNS app_public."user"
    LANGUAGE sql STABLE
    AS $$
  Select *
  From app_public.user
  Where user_id = current_setting('jwt.claims.user_id')::integer
$$;


ALTER FUNCTION app_public."current_user"() OWNER TO postgres;

--
-- Name: FUNCTION "current_user"(); Type: COMMENT; Schema: app_public; Owner: postgres
--

COMMENT ON FUNCTION app_public."current_user"() IS 'Gets the person who was identified by our JWT.';


--
-- Name: register_user(text, text, text, text, text, app_private.auth_partner); Type: FUNCTION; Schema: app_public; Owner: postgres
--

CREATE FUNCTION app_public.register_user(first_name text, last_name text, email text, password text, client_id text DEFAULT NULL::text, auth_partner app_private.auth_partner DEFAULT NULL::app_private.auth_partner) RETURNS app_public."user"
    LANGUAGE plpgsql STRICT SECURITY DEFINER
    AS $$
DECLARE
  newuser app_public.user;
BEGIN
  Insert Into app_public.user (first_name, last_name) 
  Values (first_name, last_name)
  Returning * into newuser;

  Insert Into app_private.user_account (user_id, primary_email, username, password_hash) 
  Values (newuser.user_id, email, email, crypt(password, gen_salt('bf') ) );
											  
  IF client_id IS NOT NULL THEN
	Insert into app_private.user_3P_auth (user_id, client_id, email, auth_partner)
	Values (newuser.user_id, client_id, email, auth_partner);
  END IF;

  RETURN newuser;
END;
$$;


ALTER FUNCTION app_public.register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner) OWNER TO postgres;

--
-- Name: FUNCTION register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner); Type: COMMENT; Schema: app_public; Owner: postgres
--

COMMENT ON FUNCTION app_public.register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner) IS 'Registers a single user and creates an account in our forum.';


--
-- Name: user_3p_auth; Type: TABLE; Schema: app_private; Owner: postgres
--

CREATE TABLE app_private.user_3p_auth (
    user_id integer NOT NULL,
    client_id text,
    email character varying(100),
    auth_partner app_private.auth_partner NOT NULL,
    created_on timestamp with time zone DEFAULT now(),
    modified_on timestamp with time zone DEFAULT now(),
    CONSTRAINT user_3p_auth_email_check CHECK (((email)::text ~* '^.+@.+\..+$'::text))
);


ALTER TABLE app_private.user_3p_auth OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: app_private; Owner: postgres
--

CREATE TABLE app_private.user_account (
    user_id integer NOT NULL,
    primary_email character varying(100),
    username character varying(50),
    password_hash text NOT NULL,
    status app_private.account_status DEFAULT 'active'::app_private.account_status,
    created_on timestamp with time zone DEFAULT now(),
    modified_on timestamp with time zone DEFAULT now(),
    CONSTRAINT user_account_primary_email_check CHECK (((primary_email)::text ~* '^.+@.+\..+$'::text))
);


ALTER TABLE app_private.user_account OWNER TO postgres;

--
-- Name: demo_form_public; Type: TABLE; Schema: app_public; Owner: postgres
--

CREATE TABLE app_public.demo_form_public (
    demo_id integer NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    username character varying(50),
    email character varying(100),
    password character varying(50),
    single_selection character varying(100),
    multiple_selection character varying(255),
    comment text,
    radio_selection character varying(100),
    checkbox_selection character varying(255),
    date_entry timestamp with time zone,
    time_entry timestamp with time zone,
    datetime_entry timestamp with time zone
);


ALTER TABLE app_public.demo_form_public OWNER TO postgres;

--
-- Name: demo_form_public_demo_id_seq; Type: SEQUENCE; Schema: app_public; Owner: postgres
--

CREATE SEQUENCE app_public.demo_form_public_demo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE app_public.demo_form_public_demo_id_seq OWNER TO postgres;

--
-- Name: demo_form_public_demo_id_seq; Type: SEQUENCE OWNED BY; Schema: app_public; Owner: postgres
--

ALTER SEQUENCE app_public.demo_form_public_demo_id_seq OWNED BY app_public.demo_form_public.demo_id;


--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: app_public; Owner: postgres
--

CREATE SEQUENCE app_public.user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE app_public.user_user_id_seq OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: app_public; Owner: postgres
--

ALTER SEQUENCE app_public.user_user_id_seq OWNED BY app_public."user".user_id;


--
-- Name: demo_form_public demo_id; Type: DEFAULT; Schema: app_public; Owner: postgres
--

ALTER TABLE ONLY app_public.demo_form_public ALTER COLUMN demo_id SET DEFAULT nextval('app_public.demo_form_public_demo_id_seq'::regclass);


--
-- Name: user user_id; Type: DEFAULT; Schema: app_public; Owner: postgres
--

ALTER TABLE ONLY app_public."user" ALTER COLUMN user_id SET DEFAULT nextval('app_public.user_user_id_seq'::regclass);


--
-- Data for Name: user_3p_auth; Type: TABLE DATA; Schema: app_private; Owner: postgres
--

COPY app_private.user_3p_auth (user_id, client_id, email, auth_partner, created_on, modified_on) FROM stdin;
\.
COPY app_private.user_3p_auth (user_id, client_id, email, auth_partner, created_on, modified_on) FROM '$$PATH$$/2895.dat';

--
-- Data for Name: user_account; Type: TABLE DATA; Schema: app_private; Owner: postgres
--

COPY app_private.user_account (user_id, primary_email, username, password_hash, status, created_on, modified_on) FROM stdin;
\.
COPY app_private.user_account (user_id, primary_email, username, password_hash, status, created_on, modified_on) FROM '$$PATH$$/2894.dat';

--
-- Data for Name: demo_form_public; Type: TABLE DATA; Schema: app_public; Owner: postgres
--

COPY app_public.demo_form_public (demo_id, first_name, last_name, username, email, password, single_selection, multiple_selection, comment, radio_selection, checkbox_selection, date_entry, time_entry, datetime_entry) FROM stdin;
\.
COPY app_public.demo_form_public (demo_id, first_name, last_name, username, email, password, single_selection, multiple_selection, comment, radio_selection, checkbox_selection, date_entry, time_entry, datetime_entry) FROM '$$PATH$$/2897.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: app_public; Owner: postgres
--

COPY app_public."user" (user_id, first_name, last_name, created_on, modified_on) FROM stdin;
\.
COPY app_public."user" (user_id, first_name, last_name, created_on, modified_on) FROM '$$PATH$$/2893.dat';

--
-- Name: demo_form_public_demo_id_seq; Type: SEQUENCE SET; Schema: app_public; Owner: postgres
--

SELECT pg_catalog.setval('app_public.demo_form_public_demo_id_seq', 265, true);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: app_public; Owner: postgres
--

SELECT pg_catalog.setval('app_public.user_user_id_seq', 1, false);


--
-- Name: user_3p_auth user_3p_auth_email_key; Type: CONSTRAINT; Schema: app_private; Owner: postgres
--

ALTER TABLE ONLY app_private.user_3p_auth
    ADD CONSTRAINT user_3p_auth_email_key UNIQUE (email);


--
-- Name: user_3p_auth user_3p_auth_pkey; Type: CONSTRAINT; Schema: app_private; Owner: postgres
--

ALTER TABLE ONLY app_private.user_3p_auth
    ADD CONSTRAINT user_3p_auth_pkey PRIMARY KEY (user_id, auth_partner);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: app_private; Owner: postgres
--

ALTER TABLE ONLY app_private.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (user_id);


--
-- Name: user_account user_account_primary_email_key; Type: CONSTRAINT; Schema: app_private; Owner: postgres
--

ALTER TABLE ONLY app_private.user_account
    ADD CONSTRAINT user_account_primary_email_key UNIQUE (primary_email);


--
-- Name: demo_form_public demo_form_public_email_key; Type: CONSTRAINT; Schema: app_public; Owner: postgres
--

ALTER TABLE ONLY app_public.demo_form_public
    ADD CONSTRAINT demo_form_public_email_key UNIQUE (email);


--
-- Name: demo_form_public demo_form_public_pkey; Type: CONSTRAINT; Schema: app_public; Owner: postgres
--

ALTER TABLE ONLY app_public.demo_form_public
    ADD CONSTRAINT demo_form_public_pkey PRIMARY KEY (demo_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: app_public; Owner: postgres
--

ALTER TABLE ONLY app_public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_3p_auth user_3p_auth_updated_on; Type: TRIGGER; Schema: app_private; Owner: postgres
--

CREATE TRIGGER user_3p_auth_updated_on BEFORE UPDATE ON app_private.user_3p_auth FOR EACH ROW EXECUTE PROCEDURE app_private.set_modified_on();


--
-- Name: user_account user_account_updated_on; Type: TRIGGER; Schema: app_private; Owner: postgres
--

CREATE TRIGGER user_account_updated_on BEFORE UPDATE ON app_private.user_account FOR EACH ROW EXECUTE PROCEDURE app_private.set_modified_on();


--
-- Name: user user_updated_on; Type: TRIGGER; Schema: app_public; Owner: postgres
--

CREATE TRIGGER user_updated_on BEFORE UPDATE ON app_public."user" FOR EACH ROW EXECUTE PROCEDURE app_private.set_modified_on();


--
-- Name: user_3p_auth user_3p_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: app_private; Owner: postgres
--

ALTER TABLE ONLY app_private.user_3p_auth
    ADD CONSTRAINT user_3p_auth_user_id_fkey FOREIGN KEY (user_id) REFERENCES app_public."user"(user_id) ON DELETE CASCADE;


--
-- Name: user_account user_account_user_id_fkey; Type: FK CONSTRAINT; Schema: app_private; Owner: postgres
--

ALTER TABLE ONLY app_private.user_account
    ADD CONSTRAINT user_account_user_id_fkey FOREIGN KEY (user_id) REFERENCES app_public."user"(user_id) ON DELETE CASCADE;


--
-- Name: SCHEMA app_private; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA app_private TO app_authorized;


--
-- Name: SCHEMA app_public; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA app_public TO app_anonymous;
GRANT USAGE ON SCHEMA app_public TO app_authorized;


--
-- Name: FUNCTION set_modified_on(); Type: ACL; Schema: app_private; Owner: postgres
--

REVOKE ALL ON FUNCTION app_private.set_modified_on() FROM PUBLIC;


--
-- Name: FUNCTION authenticate(username text, password text); Type: ACL; Schema: app_public; Owner: postgres
--

REVOKE ALL ON FUNCTION app_public.authenticate(username text, password text) FROM PUBLIC;
GRANT ALL ON FUNCTION app_public.authenticate(username text, password text) TO app_anonymous;
GRANT ALL ON FUNCTION app_public.authenticate(username text, password text) TO app_authorized;


--
-- Name: TABLE "user"; Type: ACL; Schema: app_public; Owner: postgres
--

GRANT SELECT ON TABLE app_public."user" TO app_anonymous;
GRANT SELECT,DELETE,UPDATE ON TABLE app_public."user" TO app_authorized;


--
-- Name: FUNCTION "current_user"(); Type: ACL; Schema: app_public; Owner: postgres
--

REVOKE ALL ON FUNCTION app_public."current_user"() FROM PUBLIC;
GRANT ALL ON FUNCTION app_public."current_user"() TO app_anonymous;
GRANT ALL ON FUNCTION app_public."current_user"() TO app_authorized;


--
-- Name: FUNCTION register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner); Type: ACL; Schema: app_public; Owner: postgres
--

REVOKE ALL ON FUNCTION app_public.register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner) FROM PUBLIC;
GRANT ALL ON FUNCTION app_public.register_user(first_name text, last_name text, email text, password text, client_id text, auth_partner app_private.auth_partner) TO app_anonymous;


--
-- Name: TABLE demo_form_public; Type: ACL; Schema: app_public; Owner: postgres
--

GRANT ALL ON TABLE app_public.demo_form_public TO app_anonymous;


--
-- Name: SEQUENCE demo_form_public_demo_id_seq; Type: ACL; Schema: app_public; Owner: postgres
--

GRANT USAGE ON SEQUENCE app_public.demo_form_public_demo_id_seq TO app_anonymous;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres REVOKE ALL ON FUNCTIONS  FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

